﻿namespace Capstone
{
    using System;
    using System.Collections.Generic;
    using System.Text;

    public class Program
    {
        public static void Main(string[] args)
        {
            Menu menu = new Menu();
            menu.Display();
        }
    }
}
